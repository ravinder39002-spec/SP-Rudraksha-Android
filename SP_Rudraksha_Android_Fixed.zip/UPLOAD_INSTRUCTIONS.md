# SP Rudraksha — Mobile GitHub Upload

This ZIP is a clean Android project plus a GitHub Actions workflow.

IMPORTANT: GitHub must contain the project files themselves, not only this ZIP file.

The repository can have the Android project at the root OR inside one folder. The workflow automatically finds `settings.gradle` + `app/build.gradle`, so the earlier nested-folder error is handled.

After the files are committed, open GitHub → Actions → Build SP Rudraksha AAB → Run workflow → Run workflow.

The successful run will have an artifact named `sp-rudraksha-release-aab` containing the AAB.

This build is an unsigned release AAB. Google Play production release still requires signing / Play App Signing setup.
