package com.sp.rudraksha;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    int brown = Color.rgb(107,50,30), cream = Color.rgb(255,248,232);

    TextView tv(String text, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(brown);
        t.setPadding(16,10,16,10);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setBackgroundColor(brown);
        return b;
    }

    void call() {
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:8607839002")));
    }

    void whatsapp() {
        Uri u = Uri.parse("https://wa.me/918607839002?text=Namaste%20SP%20Rudraksha%2C%20mujhe%20Rudraksha%20products%20ke%20baare%20mein%20jaankari%20chahiye.");
        startActivity(new Intent(Intent.ACTION_VIEW, u));
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18,18,18,28); box.setBackgroundColor(cream);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.sp.rudraksha.R.mipmap.ic_launcher);
        logo.setAdjustViewBounds(true);
        box.addView(logo, new LinearLayout.LayoutParams(-1, 230));

        TextView title = tv("SP Rudraksha", 28, true);
        title.setGravity(Gravity.CENTER);
        box.addView(title);
        TextView sub = tv("Wholesale & Retail • Haridwar, Uttarakhand\nHar Ki Pauri ke Paas", 16, false);
        sub.setGravity(Gravity.CENTER); box.addView(sub);

        box.addView(tv("Rudraksha Catalogue", 22, true));
        String[] products = {
            "1 Mukhi Rudraksha — ₹250–₹350",
            "2–10 Mukhi Rudraksha — ₹35 per bead",
            "7 Mukhi (Nepali) — ₹100",
            "Rudraksha Mala (108 beads, Nepali) — ₹22,000",
            "Karangali Mala — ₹115",
            "Tulsi Mala — ₹115"
        };
        for (String p : products) box.addView(tv("📿  " + p + "\nStock: Unlimited", 16, false));

        box.addView(tv("Ayurvedic Medicines", 22, true));
        box.addView(tv("Ayurvedic medicines section — product availability and details can be requested directly from SP Rudraksha.", 16, false));

        Button w = btn("WhatsApp Enquiry"); w.setOnClickListener(v -> whatsapp()); box.addView(w);
        Button c = btn("Call SP Rudraksha"); c.setOnClickListener(v -> call()); box.addView(c);

        box.addView(tv("Online Payment", 22, true));
        box.addView(tv("Payment QR / UPI options can be added to the final release build.", 16, false));

        box.addView(tv("Contact", 22, true));
        box.addView(tv("8607839002\nManmohan Singh: 8920206033\nSP Rudraksha, Haridwar", 16, false));

        scroll.addView(box); setContentView(scroll);
    }
}
